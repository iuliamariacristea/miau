import sys
from pathlib import Path


def main():
    """
    Creează intrarea pentru MapReduce.

    Pentru fiecare fișier .txt din folderul documents, afișează:
    document_id<TAB>continut_document

    Exemplu:
    doc1.txt    Ana are mere
    """

    if len(sys.argv) > 1:
        documents_folder = Path(sys.argv[1])
    else:
        documents_folder = Path("documents")

    if not documents_folder.exists() or not documents_folder.is_dir():
        print(f"Eroare: folderul {documents_folder} nu există.", file=sys.stderr)
        sys.exit(1)

    for file_path in sorted(documents_folder.glob("*.txt")):
        document_id = file_path.name

        try:
            text = file_path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            text = file_path.read_text(encoding="latin-1")

        text = text.replace("\n", " ")

        print(f"{document_id}\t{text}")


if __name__ == "__main__":
    main()