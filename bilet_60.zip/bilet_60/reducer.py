import sys


def emit_result(word, postings):
    """
    Afișează rezultatul pentru un cuvânt.

    Format:
    word    <(doc1.txt, 2), (doc2.txt, 1)>
    """

    parts = []

    for document_id, count in postings.items():
        parts.append(f"({document_id}, {count})")

    print(f"{word}\t<" + ", ".join(parts) + ">")


def main():
    """
    Reducer pentru index invers.

    Primește la stdin linii sortate de forma:
    word<TAB>document_id<TAB>1

    Emite:
    word<TAB><(document_id, count_word_in_document_id), ...>
    """

    current_word = None
    postings = {}

    for line in sys.stdin:
        line = line.strip()

        if not line:
            continue

        try:
            word, document_id, count = line.split("\t")
            count = int(count)
        except ValueError:
            continue

        if current_word is None:
            current_word = word

        if word != current_word:
            emit_result(current_word, postings)

            current_word = word
            postings = {}

        if document_id not in postings:
            postings[document_id] = 0

        postings[document_id] += count

    if current_word is not None:
        emit_result(current_word, postings)


if __name__ == "__main__":
    main()