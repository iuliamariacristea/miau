import sys
import re


def normalize_text(text):
    """
    Normalizează textul:
    - îl transformă în litere mici;
    - uniformizează unele variante de diacritice.
    """

    text = text.lower()

    text = text.replace("ş", "ș")
    text = text.replace("ţ", "ț")
    text = text.replace("Ş", "ș")
    text = text.replace("Ţ", "ț")

    return text


def extract_words(text):
    """
    Extrage cuvintele din text.

    Acceptă litere românești și cifre.
    Semnele de punctuație sunt ignorate.
    """

    pattern = r"[a-zA-ZăâîșțĂÂÎȘȚ0-9]+"
    return re.findall(pattern, text)


def main():
    """
    Mapper pentru index invers.

    Primește la stdin linii de forma:
    document_id<TAB>continut_document

    Emite la stdout:
    word<TAB>document_id<TAB>1
    """

    for line in sys.stdin:
        line = line.strip()

        if not line:
            continue

        try:
            document_id, text = line.split("\t", 1)
        except ValueError:
            continue

        text = normalize_text(text)
        words = extract_words(text)

        for word in words:
            print(f"{word}\t{document_id}\t1")


if __name__ == "__main__":
    main()