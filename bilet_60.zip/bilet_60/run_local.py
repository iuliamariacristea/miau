import subprocess
import sys
from pathlib import Path


def main():
    project_dir = Path(__file__).parent

    make_input_path = project_dir / "make_input.py"
    mapper_path = project_dir / "mapper.py"
    reducer_path = project_dir / "reducer.py"
    documents_path = project_dir / "documents"
    output_path = project_dir / "output.txt"

    make_input_process = subprocess.Popen(
        [sys.executable, str(make_input_path), str(documents_path)],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )

    mapper_process = subprocess.Popen(
        [sys.executable, str(mapper_path)],
        stdin=make_input_process.stdout,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )

    make_input_process.stdout.close()

    mapped_output, mapper_errors = mapper_process.communicate()
    _, make_input_errors = make_input_process.communicate()

    if make_input_errors:
        print("Erori make_input.py:")
        print(make_input_errors)

    if mapper_errors:
        print("Erori mapper.py:")
        print(mapper_errors)

    sorted_lines = sorted(mapped_output.splitlines())

    sorted_text = "\n".join(sorted_lines) + "\n"

    reducer_process = subprocess.Popen(
        [sys.executable, str(reducer_path)],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )

    final_output, reducer_errors = reducer_process.communicate(sorted_text)

    if reducer_errors:
        print("Erori reducer.py:")
        print(reducer_errors)

    output_path.write_text(final_output, encoding="utf-8")

    print("Rezultat MapReduce:")
    print(final_output)

    print(f"Rezultatul a fost salvat în: {output_path}")


if __name__ == "__main__":
    main()