import json
import time
import socket

import requests

EXCHANGE = "US"
API_KEY = "brmr2kfrh5rcss140jmg"
START_DATE = "2022-06-04"
END_DATE = "2023-06-04"


def getSymbols() -> set:
    response = requests.get(f"https://finnhub.io/api/v1/stock/symbol?exchange={EXCHANGE}&token={API_KEY}").json()

    return set(map(lambda exchange: exchange['symbol'], response))


def getSymbolNews(symbol: str) -> list:
    return requests.get(
        f"https://finnhub.io/api/v1/company-news?symbol={symbol}&from={START_DATE}&to={END_DATE}&token={API_KEY}").json()


def sendNews(client: socket):
    print("Getting symbols...")
    symbols = getSymbols()
    for symbol in symbols:
        print(symbol)
        news = getSymbolNews(symbol)
        for new in news:
            newStr = json.dumps(new)
            print("Sending", newStr)
            client.send((newStr + "\r\n").encode('ascii'))
            time.sleep(3)


if __name__ == '__main__':
    with socket.create_server(("127.0.0.1", 6789)) as server:
        print("Waiting connection...w")
        conn, addr = server.accept()
        print('Connection received: {}'.format(addr))
        sendNews(conn)
