package org.example

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import org.apache.spark.SparkConf
import org.apache.spark.api.java.JavaSparkContext
import org.apache.spark.streaming.Durations
import org.apache.spark.streaming.api.java.JavaDStream
import org.apache.spark.streaming.api.java.JavaReceiverInputDStream
import org.apache.spark.streaming.api.java.JavaStreamingContext

@Serializable
data class News(
    val category: String,
    val datetime: Int,
    val headline: String,
    val id: Int,
    val image: String,
    val related: String,
    val source: String,
    val summary: String,
    val url: String,
)

fun main(args: Array<String>) {
// configurarea Spark
    val sparkConf = SparkConf().setMaster("local[4]").setAppName("SparkExample")
// initializarea contextului Spark
    val sparkContext = JavaSparkContext(sparkConf)
    val jssc = JavaStreamingContext(sparkContext, Durations.seconds(10))

    val lines: JavaReceiverInputDStream<String> =
        jssc.socketTextStream("localhost", 6789)

    val aux: JavaDStream<String> = lines
        .map { Json.decodeFromString<News>(it?:"") } // Parse News object
        .filter { it.source != "Yahoo" }
        .filter { it.summary.length <= 500 }
        .map { "\tUrl: ${it.url}\n\tTimestamp: ${it.datetime}\n\tTitle: ${it.headline}\n\tSource: ${it.source}" }

    aux.print()

    // oprirea contextului Spark
    // Start the computation
    jssc.start()
    jssc.awaitTermination()
    sparkContext.stop()
}